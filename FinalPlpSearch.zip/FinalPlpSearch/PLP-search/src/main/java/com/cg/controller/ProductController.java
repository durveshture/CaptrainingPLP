package com.cg.controller;

import java.util.NoSuchElementException;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Product;
import com.cg.service.ProductService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class ProductController {
 
	
	
	@Autowired
	private ProductService service;

	@GetMapping(path = "/getproduct", produces = "application/json")
	ResponseEntity<?> findProduct(@RequestParam("queryString") String queryString) {

		Iterable<Product> productList;
		int productId;
		long count;
      
		queryString=queryString.toLowerCase();
		if (queryString == null) {
			return new ResponseEntity<String>("Please enter a search keyword", HttpStatus.BAD_REQUEST);
		} else {
			try {
				productList = service.findByProductName(queryString);
				count = StreamSupport.stream(productList.spliterator(), false).count();
				if (count != 0) {
					return new ResponseEntity<Iterable<Product>>(productList, HttpStatus.OK);
				}
				productList = service.findByProductBrand(queryString);
				count = StreamSupport.stream(productList.spliterator(), false).count();
				if (count != 0) {
					return new ResponseEntity<Iterable<Product>>(productList, HttpStatus.OK);
				}
				
			} catch (NoSuchElementException e) {
				return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
			} finally {
				count = 0;
			}
		}
		return null;

	}
	
	@PostMapping(path="/addproducts")
	String addProducts(){
		service.saveProduct();
		return "Products added";		
	}
}
