package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Product")
public class Product {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(length=20)
	private int id;
	
	@Column(length=20)
	private int catId;
	
	@Column(length=20)
	private String name;
	
	@Column(length=20)
	private String brand;
	

	


	public int getProductId() {
		return id;
	}

	public void setProductId(int productId) {
		this.id = productId;
	}

	public int getCategoryId() {
		return catId;
	}

	public void setCategoryId(int categoryId) {
		this.catId = categoryId;
	}

	public String getProductName() {
		return name;
	}

	public void setProductName(String productName) {
		this.name = productName;
	}

	public String getProductBrand() {
		return brand;
	}

	public void setProductBrand(String productBrand) {
		this.brand = productBrand;
	}


	
	
}
