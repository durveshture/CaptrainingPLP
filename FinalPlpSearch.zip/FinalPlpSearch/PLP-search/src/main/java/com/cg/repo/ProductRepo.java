package com.cg.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import com.cg.entity.Product;

public interface ProductRepo extends CrudRepository<Product, Integer>,Repository<Product, Integer> {

	@Query(value = "from Product p where p.name like %:query%")
	Iterable<Product> findByProdName(@Param("query") String productName);
	
	@Query(value = "from Product p where p.brand like %:query%")
	Iterable<Product> findByProdBrand(@Param("query") String productBrand);

}
