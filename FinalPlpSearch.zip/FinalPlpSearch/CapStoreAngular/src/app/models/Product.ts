/*  author: Durvesh Ture(173571)
 *  version: 1.0.1
 */

export class ProductModel{
 productId: number;
 categoryId: number;
 productName: String;
 productBrand: String;
 productDescription: String;
 viewCount: number;
 actualPrice: number ;
 discountPrice: number ;
 productQuantity: number ;
}
