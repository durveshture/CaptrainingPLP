package com.cg.controller;

import java.util.NoSuchElementException;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Customer;
import com.cg.entity.Merchant;
import com.cg.entity.Product;
import com.cg.service.Service;

@RestController
// @CrossOrigin(origins = "http://localhost:4200")
public class ProductController {

	@Autowired
	private Service service;

	@GetMapping(path = "/getproduct", produces = "application/json")
	ResponseEntity<?> findProduct(@RequestParam("queryString") String queryString) {

		Iterable<Product> productList;
		long count;

		queryString = queryString.toLowerCase();
		if (queryString == null) {
			return new ResponseEntity<String>("Please enter a search keyword", HttpStatus.BAD_REQUEST);
		} else {
			try {
				productList = service.findByProductName(queryString);
				count = StreamSupport.stream(productList.spliterator(), false).count();
				if (count != 0) {
					return new ResponseEntity<Iterable<Product>>(productList, HttpStatus.OK);
				}
				productList = service.findByProductBrand(queryString);
				count = StreamSupport.stream(productList.spliterator(), false).count();
				if (count != 0) {
					return new ResponseEntity<Iterable<Product>>(productList, HttpStatus.OK);
				}

			} catch (NoSuchElementException e) {
				return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
			} finally {
				count = 0;
			}
		}
		return null;

	}

	@GetMapping(path = "/getcustomer", produces = "application/json")
	ResponseEntity<?> findCustomer(@RequestParam("queryString") String queryString) {

		Iterable<Customer> customerList;
		long count;

		queryString = queryString.toLowerCase();
		if (queryString == null) {
			return new ResponseEntity<String>("Please enter a search keyword", HttpStatus.BAD_REQUEST);
		} else {
			try {
				customerList = service.findByCustomerFirstName(queryString);
				count = StreamSupport.stream(customerList.spliterator(), false).count();
				if (count != 0) {
					return new ResponseEntity<Iterable<Customer>>(customerList, HttpStatus.OK);
				}

				customerList = service.findByCustomerLastName(queryString);
				count = StreamSupport.stream(customerList.spliterator(), false).count();
				if (count != 0) {
					return new ResponseEntity<Iterable<Customer>>(customerList, HttpStatus.OK);
				}

			} catch (NoSuchElementException e) {
				return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
			} finally {
				count = 0;
			}
		}
		return null;

	}

	@GetMapping(path = "/getmerchant", produces = "application/json")
	ResponseEntity<?> findMerchant(@RequestParam("queryString") String queryString) {

		Iterable<Merchant> merchantList;
		long count;

		queryString = queryString.toLowerCase();
		if (queryString == null) {
			return new ResponseEntity<String>("Please enter a search keyword", HttpStatus.BAD_REQUEST);
		} else {
			try {
				merchantList = service.findByMerchantFirstName(queryString);
				count = StreamSupport.stream(merchantList.spliterator(), false).count();
				if (count != 0) {
					return new ResponseEntity<Iterable<Merchant>>(merchantList, HttpStatus.OK);
				}

				merchantList = service.findByMerchantLastName(queryString);
				count = StreamSupport.stream(merchantList.spliterator(), false).count();
				if (count != 0) {
					return new ResponseEntity<Iterable<Merchant>>(merchantList, HttpStatus.OK);
				}

			} catch (NoSuchElementException e) {
				return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
			} finally {
				count = 0;
			}
		}
		return null;

	}

	@PostMapping(path = "/addproducts")
	String addProducts() {
		service.saveProduct();
		return "Products added";
	}

	@PostMapping(path = "/addmerchants")
	String addMerchants() {
		service.saveMerchant();
		return "merchants added";
	}

	@PostMapping(path = "/addcustomers")
	String addCustomers() {
		service.saveCustomer();
		return "customers added";
	}
}
