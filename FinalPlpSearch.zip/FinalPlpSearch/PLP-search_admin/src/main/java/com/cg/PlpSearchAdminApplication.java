package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlpSearchAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlpSearchAdminApplication.class, args);
	}

}
