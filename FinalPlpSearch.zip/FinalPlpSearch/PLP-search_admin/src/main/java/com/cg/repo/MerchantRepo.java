package com.cg.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.cg.entity.Merchant;
import com.cg.entity.Product;

public interface MerchantRepo extends CrudRepository<Merchant, Integer> {

	@Query(value = "from Merchant m where m.firstName like %:query%")
	Iterable<Merchant>findByMerchantFirstName(@Param("query") String firstName);
	
	@Query(value = "from Merchant m where m.lastName like %:query%")
	Iterable<Merchant>findByMerchantLastName(@Param("query") String lastName);
}
