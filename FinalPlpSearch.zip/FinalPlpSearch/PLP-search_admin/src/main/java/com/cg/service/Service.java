package com.cg.service;

import com.cg.entity.Customer;
import com.cg.entity.Merchant;
import com.cg.entity.Product;

public interface Service {

	Iterable<Product> findByProductName(String productName);

	Iterable<Product> findByProductBrand(String productBrand);
	
	Iterable<Merchant> findByMerchantFirstName(String firstName);
	
	Iterable<Merchant> findByMerchantLastName(String lastName);
	
	Iterable<Customer> findByCustomerFirstName(String firstName);
	
	Iterable<Customer> findByCustomerLastName(	String lastName);

	public void saveProduct();
	
	public void saveMerchant();
	
	public void saveCustomer();
}
