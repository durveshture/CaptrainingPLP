package com.cg.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.cg.entity.Customer;
import com.cg.entity.Product;

public interface CustomerRepo extends CrudRepository<Customer, Integer> {

	@Query(value = "from Customer c where c.firstName like %:query%")
	Iterable<Customer>findByCustomerFirstName(@Param("query") String firstName);
	
	@Query(value = "from Customer c where c.lastName like %:query%")
	Iterable<Customer>findByCustomerLastName(@Param("query") String lastName);
}


