package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Customer;
import com.cg.entity.Merchant;
import com.cg.entity.Product;
import com.cg.repo.CustomerRepo;
import com.cg.repo.MerchantRepo;
import com.cg.repo.ProductRepo;


@Service
@Transactional
public class ServiceImpl implements com.cg.service.Service {


	
	@Autowired
	private ProductRepo productRepo;
	
	@Autowired
	private CustomerRepo customerRepo;
	
	@Autowired
	private MerchantRepo merchantRepo;
	
	@Override
	public Iterable<Product> findByProductName(String productName) {
		return productRepo.findByProdName(productName);
		
	}

	@Override
	public Iterable<Product> findByProductBrand(String productBrand) {
		return productRepo.findByProdBrand(productBrand);
	}

	@Override
	public Iterable<Merchant> findByMerchantFirstName(String firstName) {
		return merchantRepo.findByMerchantFirstName(firstName);
	}

	@Override
	public Iterable<Merchant> findByMerchantLastName(String lastName) {
		return merchantRepo.findByMerchantLastName(lastName);
	}

	@Override
	public Iterable<Customer> findByCustomerFirstName(String firstName) {
		return customerRepo.findByCustomerFirstName(firstName);
	}

	@Override
	public Iterable<Customer> findByCustomerLastName(String lastName) {
		return customerRepo.findByCustomerLastName(lastName);
	}

	
     @Override
	public void saveProduct() {
		Product p1= new Product();
		Product p2= new Product();
		Product p3= new Product();
		Product p4= new Product();
		Product p5= new Product();
		Product p6= new Product();
		Product p7= new Product();
		Product p8= new Product();
		Product p9= new Product();
		Product p10= new Product();
		Product p11= new Product();
		
		p1.setProductName("galaxy s10");
		p1.setProductBrand("samsung");
		
		p2.setProductName("8.1");
		p2.setProductBrand("nokia");
		
		p3.setProductName("asha");
		p3.setProductBrand("nokia");
		
		p4.setProductName("iphone 8");
		p4.setProductBrand("apple");
		
		p5.setProductName("iphone 6");
		p5.setProductBrand("apple");
		
		p6.setProductName("z2 plus");
		p6.setProductBrand("lenovo");
		
		p7.setProductName("note 8");
		p7.setProductBrand("mi");
		
		p8.setProductName("v7");
		p8.setProductBrand("vivo");
		
		p9.setProductName("v5 pro");
		p9.setProductBrand("oppo");
		
		p10.setProductName("note 5");
		p10.setProductBrand("xiomi");
		
		p11.setProductName("one");
		p11.setProductBrand("lava");
		productRepo.save(p11);
		productRepo.save(p1);
		productRepo.save(p2);
		productRepo.save(p3);
		productRepo.save(p4);
		productRepo.save(p5);
		productRepo.save(p6);
		productRepo.save(p7);
		productRepo.save(p8);
		productRepo.save(p9);
		productRepo.save(p10);
		
	}

	@Override
	public void saveMerchant() {
		
		Merchant merchant1= new Merchant();
		Merchant merchant2= new Merchant();
		Merchant merchant3= new Merchant();
		Merchant merchant4= new Merchant();
		
		merchant1.setFirstName("aditya");
		merchant1.setLastName("sinha");
		merchant1.setContact("8452802152");
		merchant2.setFirstName("Mayur");
		merchant2.setLastName("Shinde");
		merchant2.setContact("7977918162");
		merchant3.setFirstName("Durvesh");
		merchant3.setLastName("Ture");
		merchant3.setContact("9856942642");
		merchant4.setFirstName("tushar");
		merchant4.setLastName("gawhale");
		merchant4.setContact("9869430282");
		
		merchantRepo.save(merchant1);
		merchantRepo.save(merchant2);
		merchantRepo.save(merchant3);
		merchantRepo.save(merchant4);
		
	}

	@Override
	public void saveCustomer() {
		
		Customer customer1= new Customer();
		Customer customer2= new Customer();
		Customer customer3= new Customer();
		Customer customer4= new Customer();
		
		customer1.setFirstName("pratik");
		customer1.setLastName("mayba");
		customer2.setFirstName("tejas");
		customer2.setLastName("mungekar");
		customer3.setFirstName("kirit");
		customer3.setLastName("sawant");
		customer4.setFirstName("prathamesh");
		customer4.setLastName("deogharkar");
		
		customerRepo.save(customer1);
		customerRepo.save(customer2);
		customerRepo.save(customer3);
		customerRepo.save(customer4);
		
	}
	

}
