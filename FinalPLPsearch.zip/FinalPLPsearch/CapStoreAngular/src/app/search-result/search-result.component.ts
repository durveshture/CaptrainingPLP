import { ProductModel } from './../models/Product';
import { Component, OnInit } from '@angular/core';
import { SearchServiceService } from '../search-service.service';

@Component({
  selector: 'app-search-result',
  templateUrl: './search-result.component.html',
  styleUrls: ['./search-result.component.css']
})
export class SearchResultComponent implements OnInit {

  product = new ProductModel();
  productArr: ProductModel[] = [];
  queryString: String;
  resultTrue = false;

  constructor(private service: SearchServiceService) { }

  ngOnInit() {
  }

  getAll() {
    this.service.getProducts(this.queryString).subscribe(
      result => {
        this.productArr = result;
        this.resultTrue = true;
       }

    );
  }

}
