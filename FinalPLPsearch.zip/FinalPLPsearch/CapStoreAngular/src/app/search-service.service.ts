import { Injectable } from '@angular/core';
import { ProductModel } from './models/Product';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class SearchServiceService {

  constructor(private http: HttpClient) { }

  baseHref="http://localhost:8280";

  getProducts(queryString: String) {
    return this.http.get<ProductModel[]>(this.baseHref + '/getproduct/?queryString=' + queryString);
  }

}
