export class ProductModel{
 productId: number;
 categoryId: number;
 productName: String;
 productBrand: String;
 productDescription: String;
 viewCount: number;
 actualPrice: number ;
 discountPrice: number ;
 productQuantity: number ;
}
