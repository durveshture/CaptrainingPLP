package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {


	
	@Autowired
	private ProductRepo repo;
	
	@Override
	public Iterable<Product> findByProductName(String productName) {
		return repo.findByProdName(productName);
		
	}

	@Override
	public Iterable<Product> findByProductBrand(String productBrand) {
		return repo.findByProdBrand(productBrand);
	}

	@Override
	public Product findById(int id) {
		return repo.findById(id).get();
	}

	@Override
	public void saveProduct() {
		Product p1= new Product();
		Product p2= new Product();
		Product p3= new Product();
		Product p4= new Product();
		Product p5= new Product();
		Product p6= new Product();
		Product p7= new Product();
		Product p8= new Product();
		Product p9= new Product();
		Product p10= new Product();
		Product p11= new Product();
		
		p1.setProductName("galaxy s10");
		p1.setProductBrand("samsung");
		
		p2.setProductName("8.1");
		p2.setProductBrand("nokia");
		
		p3.setProductName("asha");
		p3.setProductBrand("nokia");
		
		p4.setProductName("iphone 8");
		p4.setProductBrand("apple");
		
		p5.setProductName("iphone 6");
		p5.setProductBrand("apple");
		
		p6.setProductName("z2 plus");
		p6.setProductBrand("lenovo");
		
		p7.setProductName("note 8");
		p7.setProductBrand("mi");
		
		p8.setProductName("v7");
		p8.setProductBrand("vivo");
		
		p9.setProductName("v5 pro");
		p9.setProductBrand("oppo");
		
		p10.setProductName("note 5");
		p10.setProductBrand("xiomi");
		
		p11.setProductName("one");
		p11.setProductBrand("lava");
		repo.save(p11);
		repo.save(p1);
		repo.save(p2);
		repo.save(p3);
		repo.save(p4);
		repo.save(p5);
		repo.save(p6);
		repo.save(p7);
		repo.save(p8);
		repo.save(p9);
		repo.save(p10);
		
	}
	
	

}
