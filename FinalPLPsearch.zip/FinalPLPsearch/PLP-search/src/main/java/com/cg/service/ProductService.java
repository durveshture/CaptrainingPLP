package com.cg.service;

import com.cg.entity.Product;

public interface ProductService {

	Iterable<Product> findByProductName(String productName);

	Iterable<Product> findByProductBrand(String productBrand);

	Product findById(int id);

	public void saveProduct();
}
